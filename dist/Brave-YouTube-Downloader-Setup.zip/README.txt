====================================================================
           Brave YouTube yt-dlp Downloader - 1-Click Setup
====================================================================

HOW TO INSTALL IN 10 SECONDS:
1. Double-click "Install.bat"
2. The installer will automatically:
   - Check & install required dependencies (yt-dlp, FFmpeg, Node)
   - Set up the Native Messaging Host
   - Register Brave & Chrome Registry keys
   - Open Brave extensions page (brave://extensions)
3. In Brave, turn ON "Developer mode" (top-right switch).
4. Click "Load unpacked" (top-left) and select the extension folder
   (the installer automatically copies the path to your clipboard
    and opens the folder for you!).
5. Done! Enjoy seamless 4K/1080p downloads with file sizes directly in YouTube!

HOW TO UNINSTALL:
- Run "Uninstall.bat" anytime to cleanly remove registry keys and files.
====================================================================
